function dataTypeBool() {
  return 2 > 1;
}

function resultDatatBool() {
  alert("Résultat : " + dataTypeBool());
}

document.getElementById("datatBool").innerHTML = "console.log(2 > 1); //true";
