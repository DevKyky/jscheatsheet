const buttons = document.querySelectorAll(".number");
const operators = document.querySelectorAll(".operator");

let result = document.getElementById("result");
let calcul = document.getElementById("calcul");
let total;

const clear = () => {
  result.value = "";
  calcul.value = "";
  total = null;
};

const operation = () => {
  calcul.value = result.value;
  result.value = eval(result.value);
  total = result.value;
};

buttons.forEach((button) => {
  button.addEventListener("click", (e) => {
    result.value == undefined
      ? (result.value = e.target.id)
      : (result.value += e.target.id);
  });
});

operators.forEach((operator) => {
  operator.addEventListener("click", (e) => {
    switch (operator.id) {
      case "clear":
        clear();
        break;

      case "=":
        operation();
        break;

      default:
        result.value += " " + e.target.id + " ";
        break;
    }
  });
});
