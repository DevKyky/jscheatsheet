function operateurChaineCaractere1() {
  return "chaîne de " + "caractères";
}

function resultOpeChaineCarac1() {
  alert("Résultat : " + operateurChaineCaractere1());
}

document.getElementById("operateurChaineCaractere1").innerHTML =
  'console.log("chaîne de " + "caractères");';
